export enum Screen {
  INTRO,
  NAME,
  GENRE,
  QUESTIONS,
  LOADING,
  RESULT,
}

export interface ResultData {
  characterName: string;
  description: string;
  strengths: string;
  weaknesses: string;
  voiceMessage: string;
}

export interface Genre {
  id: string;
  name: string;
  imageUrl: string;
}

export interface Question {
  question: string;
  options: string[];
}