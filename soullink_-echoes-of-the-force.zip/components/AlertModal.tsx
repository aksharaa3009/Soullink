import React, { useEffect } from 'react';

interface AlertModalProps {
  onClose: () => void;
  children: React.ReactNode;
}

const AlertModal: React.FC<AlertModalProps> = ({ onClose, children }) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 animate-fade-in"
      onClick={onClose}
    >
      <style>{`
        @keyframes fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .animate-fade-in {
            animation: fade-in 0.3s ease-out forwards;
        }
      `}</style>
      <div
        className="bg-gray-900 border-2 border-red-600 rounded-xl shadow-2xl shadow-red-500/30 p-6 text-center max-w-sm w-full"
        onClick={e => e.stopPropagation()}
      >
        {children}
        <button
          onClick={onClose}
          className="mt-6 px-6 py-2 bg-red-600 text-white font-bold rounded-lg shadow-[0_0_10px_rgba(255,0,0,0.6)] hover:bg-red-500 hover:scale-105 transition-all duration-300 font-orbitron"
        >
          Understood, My Lord
        </button>
      </div>
    </div>
  );
};

export default AlertModal;
