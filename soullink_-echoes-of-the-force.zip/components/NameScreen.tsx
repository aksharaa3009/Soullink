import React, { useState } from 'react';

interface NameScreenProps {
  onSubmit: (name: string) => void;
}

const NameScreen: React.FC<NameScreenProps> = ({ onSubmit }) => {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onSubmit(name.trim());
    }
  };

  return (
    <div className="flex flex-col items-center justify-center text-center text-white w-full max-w-md p-8 bg-black/50 backdrop-blur-sm rounded-xl shadow-2xl shadow-cyan-500/20 border border-cyan-500/20">
      <h1 className="text-3xl font-orbitron text-glow mb-1">🌌 SoulLink</h1>
      <h2 className="text-md font-orbitron text-cyan-400 mb-8">Echoes of the Force</h2>
      <h2 className="text-2xl font-orbitron text-glow mb-6">Identify Yourself, Traveler</h2>
      <form onSubmit={handleSubmit} className="w-full flex flex-col items-center">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter your galactic name..."
          className="w-full px-4 py-3 bg-gray-900/80 border-2 border-cyan-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:border-cyan-400 transition-all duration-300 text-center"
        />
        <button
          type="submit"
          disabled={!name.trim()}
          className="mt-6 px-8 py-3 bg-cyan-500 text-black font-bold rounded-lg shadow-[0_0_15px_rgba(75,204,255,0.8)] hover:bg-cyan-400 hover:scale-105 transition-all duration-300 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:shadow-none disabled:hover:scale-100 font-orbitron"
        >
          Continue
        </button>
      </form>
    </div>
  );
};

export default NameScreen;