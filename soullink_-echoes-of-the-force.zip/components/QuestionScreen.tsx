
import React from 'react';
import { Question } from '../types';

interface QuestionScreenProps {
  question: Question;
  onAnswer: (answerIndex: number) => void;
  questionNumber: number;
  totalQuestions: number;
}

const QuestionScreen: React.FC<QuestionScreenProps> = ({ question, onAnswer, questionNumber, totalQuestions }) => {
  return (
    <div className="flex flex-col items-center text-center text-white w-full max-w-2xl p-8 bg-black/50 backdrop-blur-sm rounded-xl shadow-2xl shadow-cyan-500/20 border border-cyan-500/20">
      <p className="font-orbitron text-cyan-400 mb-2">Question {questionNumber} of {totalQuestions}</p>
      <h2 className="text-2xl md:text-3xl font-semibold mb-8 min-h-[6rem]">{question.question}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => onAnswer(index)}
            className="w-full px-4 py-3 bg-gray-800/70 border border-cyan-700 rounded-lg text-white hover:bg-cyan-600 hover:border-cyan-500 hover:scale-105 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-cyan-400"
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuestionScreen;
