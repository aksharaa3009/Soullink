
import React, { useState, useEffect } from 'react';

const loadingLines = [
  "The Force is strong with you...",
  "Analyzing your connection to the cosmos...",
  "Consulting the SoulLink Oracle...",
  "Aligning the cosmic streams...",
  "Establishing galactic connection...",
];

const LoadingScreen = () => {
  const [line, setLine] = useState("The Force is strong with you...");
  const [subline, setSubline] = useState("Please wait.");
  
  useEffect(() => {
    let currentIndex = 0;
    const interval = setInterval(() => {
        currentIndex = (currentIndex + 1) % loadingLines.length;
        setLine(loadingLines[currentIndex]);
    }, 2500);

    return () => clearInterval(interval);
  }, []);

   useEffect(() => {
    let sublineText = "Please wait";
    let dotCount = 0;
    const sublineInterval = setInterval(() => {
        dotCount = (dotCount + 1) % 4;
        setSubline(sublineText + '.'.repeat(dotCount));
    }, 500);

    return () => clearInterval(sublineInterval);
   }, []);

  return (
    <div className="flex flex-col items-center text-center text-white">
      <div className="w-16 h-16 border-4 border-t-cyan-400 border-r-cyan-400 border-b-transparent border-l-transparent rounded-full animate-spin mb-6"></div>
      <h2 className="text-3xl font-orbitron text-glow transition-opacity duration-500">{line}</h2>
      <p className="text-lg text-cyan-300 mt-2">{subline}</p>
    </div>
  );
};

export default LoadingScreen;
