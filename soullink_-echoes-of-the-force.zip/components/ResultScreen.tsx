
import React from 'react';
import { ResultData } from '../types';

interface ResultScreenProps {
  result: ResultData;
  onRestart: () => void;
}

const ResultScreen: React.FC<ResultScreenProps> = ({ result, onRestart }) => {
  return (
    <div className="flex flex-col items-center text-center text-white w-full max-w-2xl animate-fade-in">
      <style>{`
        @keyframes fade-in {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fade-in 1s ease-out forwards;
        }
      `}</style>
      <h2 className="text-3xl md:text-4xl font-orbitron text-glow mb-6">Your Galactic Twin Is...</h2>
      <div className="w-full p-8 bg-black/60 backdrop-blur-md rounded-xl shadow-2xl shadow-cyan-500/30 border border-cyan-500/30">
        
        <h3 className="text-4xl font-bold font-orbitron text-yellow-300 text-glow-yellow mb-4">{result.characterName}</h3>
        <p className="text-lg text-gray-300 mb-6 italic">"{result.description}"</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left mb-6">
          <div>
            <h4 className="font-orbitron text-xl text-cyan-400 mb-2">Shared Strengths</h4>
            <p className="text-gray-200">{result.strengths}</p>
          </div>
          <div>
            <h4 className="font-orbitron text-xl text-red-400 mb-2">Shared Weaknesses</h4>
            <p className="text-gray-200">{result.weaknesses}</p>
          </div>
        </div>

        <div className="mt-6 border-t border-cyan-800 pt-6">
          <h4 className="font-orbitron text-xl text-cyan-400 mb-3">A Message From Your Twin:</h4>
          <div className="p-4 bg-gray-900/50 rounded-lg border border-gray-700">
            <p className="text-lg italic text-cyan-200">"{result.voiceMessage}"</p>
          </div>
        </div>
      </div>

      <button
        onClick={onRestart}
        className="mt-8 px-8 py-3 bg-cyan-500 text-black font-bold rounded-lg shadow-[0_0_15px_rgba(75,204,255,0.8)] hover:bg-cyan-400 hover:scale-105 transition-all duration-300 font-orbitron"
      >
        Discover Another
      </button>
    </div>
  );
};

export default ResultScreen;
