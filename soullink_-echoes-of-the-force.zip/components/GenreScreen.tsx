
import React from 'react';
import { Genre } from '../types';
import { GENRES } from '../constants';

interface GenreScreenProps {
  onSelect: (genre: Genre) => void;
  error: string | null;
}

const GenreCard: React.FC<{ genre: Genre; onClick: () => void }> = ({ genre, onClick }) => (
  <div
    onClick={onClick}
    className="group relative w-full h-40 md:w-56 md:h-56 cursor-pointer overflow-hidden rounded-lg shadow-lg transform transition-all duration-300 hover:scale-105 hover:shadow-cyan-500/50"
  >
    <img src={genre.imageUrl} alt={genre.name} className="w-full h-full object-cover" />
    <div className="absolute inset-0 bg-black/60 group-hover:bg-black/40 transition-colors duration-300 flex items-center justify-center">
      <p className="text-2xl font-orbitron text-white text-glow transition-transform duration-300 group-hover:scale-110">{genre.name}</p>
    </div>
  </div>
);

const GenreScreen: React.FC<GenreScreenProps> = ({ onSelect, error }) => {
  return (
    <div className="flex flex-col items-center text-center text-white w-full max-w-4xl">
      <h2 className="text-3xl md:text-4xl font-orbitron text-glow mb-8">Choose Your Universe</h2>
      {error && <p className="mb-4 text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 p-4">
        {GENRES.map(genre => (
          <GenreCard key={genre.id} genre={genre} onClick={() => onSelect(genre)} />
        ))}
      </div>
    </div>
  );
};

export default GenreScreen;
