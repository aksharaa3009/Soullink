import React, { useState, useEffect } from 'react';

interface IntroScreenProps {
  onStart: () => void;
}

const IntroScreen: React.FC<IntroScreenProps> = ({ onStart }) => {
  const [visible, setVisible] = useState({
    line1: false,
    line2: false,
    line3: false,
    button: false,
  });

  useEffect(() => {
    const timers = [
      setTimeout(() => setVisible(s => ({ ...s, line1: true })), 500),
      setTimeout(() => setVisible(s => ({ ...s, line2: true })), 2000), // Increased delay
      setTimeout(() => setVisible(s => ({ ...s, line3: true })), 3500), // Increased delay
      setTimeout(() => setVisible(s => ({ ...s, button: true })), 5000), // Increased delay
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  const textTransition = "transition-all duration-1000 ease-out";

  return (
    <div className="flex flex-col items-center justify-center text-center text-white w-full max-w-4xl mx-auto">
      {/* Container for the cinematic text */}
      <div className="flex flex-col justify-center items-center min-h-[20rem] mb-8">
        <h2
          className={`${textTransition} text-2xl md:text-4xl text-cyan-300 mb-12 font-orbitron text-glow-yellow ${visible.line1 ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-5'}`}
        >
          A long time ago in a galaxy far, far away....
        </h2>

        <div className="flex flex-col items-center">
            <h1
              className={`${textTransition} text-4xl md:text-7xl font-bold font-orbitron mb-4 text-glow-yellow tracking-widest ${visible.line2 ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`}
            >
              SOULLINK
            </h1>
            <p
              className={`${textTransition} text-xl md:text-3xl text-cyan-300 font-orbitron text-glow-yellow ${visible.line3 ? 'opacity-100' : 'opacity-0'}`}
              style={{ transitionDelay: '200ms' }}
            >
              ECHOES OF THE FORCE
            </p>
        </div>
      </div>
      
      <div className="relative group">
        <button
          onClick={onStart}
          className={`px-8 py-3 bg-cyan-500 text-black font-bold rounded-lg shadow-[0_0_15px_rgba(75,204,255,0.8)] hover:bg-cyan-400 hover:scale-105 transition-all duration-500 font-orbitron text-lg ${visible.button ? 'opacity-100' : 'opacity-0'}`}
        >
          Begin Your Journey
        </button>
        <div className={`absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-max whitespace-nowrap px-3 py-1.5 text-xs font-semibold text-black bg-yellow-300 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none ${!visible.button && 'hidden'}`}>
          “Do or do not. There is no try.”
          <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-[6px] border-t-yellow-300"></div>
        </div>
      </div>

    </div>
  );
};

export default IntroScreen;