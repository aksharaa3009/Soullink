
import React from 'react';

const Background = () => {
  // We'll generate a number of stars programmatically for a more random, natural feel.
  const twinklingStars = React.useMemo(() => {
    return Array.from({ length: 25 }).map(() => ({
      top: `${Math.random() * 100}%`,
      left: `${Math.random() * 100}%`,
      size: Math.random() * 2 + 1, // size between 1px and 3px
      duration: `${Math.random() * 3 + 2}s`, // duration between 2s and 5s
      delay: `${Math.random() * 5}s`,
    }));
  }, []);

  return (
    <>
      <style>{`
        @keyframes stars {
          0% { transform: translateY(0); }
          100% { transform: translateY(-2000px); }
        }
        @keyframes meteor {
          0% { transform: translateX(150vw) translateY(-100px); opacity: 1; }
          70% { opacity: 1; }
          100% { transform: translateX(-50vw) translateY(600px); opacity: 0; }
        }
        @keyframes planet-float1 {
          0%, 100% { transform: translateY(-5px) translateX(-5px); }
          50% { transform: translateY(5px) translateX(5px); }
        }
        @keyframes planet-float2 {
          0%, 100% { transform: translateY(8px) translateX(-4px); }
          50% { transform: translateY(-8px) translateX(4px); }
        }
        @keyframes twinkle {
          0%, 100% {
            opacity: 0.7;
            transform: scale(0.9);
            box-shadow: 0 0 5px 1px rgba(255, 255, 255, 0.7);
          }
          50% {
            opacity: 1;
            transform: scale(1.1);
            box-shadow: 0 0 10px 2px rgba(200, 220, 255, 0.9);
          }
        }
        .animate-twinkle {
          animation-name: twinkle;
          animation-iteration-count: infinite;
          animation-timing-function: ease-in-out;
        }
      `}</style>
      <div className="absolute inset-0 z-0 bg-black overflow-hidden">
        {/* The distant, non-twinkling stars for depth */}
        <div id="stars1" className="absolute top-0 left-0 w-px h-px bg-white animate-[stars_150s_linear_infinite]" style={{boxShadow: '7px 74vh 0px #fff, 93px 9vh 1px #fff, 142px 3vh 1px #fff, 203px 20vh 1px #fff, 298px 89vh 0px #fff, 401px 81vh 1px #fff, 439px 2vh 1px #fff, 474px 6vh 0px #fff, 514px 23vh 0px #fff, 574px 7vh 1px #fff, 599px 40vh 0px #fff, 638px 97vh 1px #fff, 690px 4vh 1px #fff, 735px 23vh 0px #fff, 804px 90vh 1px #fff, 858px 33vh 1px #fff, 915px 17vh 0px #fff, 959px 3vh 1px #fff'}}></div>
        <div id="stars2" className="absolute top-0 left-0 w-1 h-1 bg-white rounded-full animate-[stars_100s_linear_infinite]" style={{boxShadow: '15px 45vh 0px #fff, 83px 29vh 1px #fff, 132px 13vh 1px #fff, 253px 30vh 1px #fff, 288px 9vh 0px #fff, 311px 8vh 1px #fff, 419px 12vh 1px #fff, 464px 16vh 0px #fff, 504px 33vh 0px #fff, 564px 17vh 1px #fff, 589px 50vh 0px #fff, 628px 77vh 1px #fff, 680px 14vh 1px #fff, 725px 33vh 0px #fff, 814px 70vh 1px #fff, 848px 43vh 1px #fff, 905px 27vh 0px #fff, 969px 13vh 1px #fff'}}></div>
        
        {/* The closer, glowing and twinkling stars */}
        <div className="absolute inset-0 z-10">
          {twinklingStars.map((star, i) => (
            <div
              key={`twinkle-${i}`}
              className="absolute bg-white rounded-full animate-twinkle"
              style={{
                top: star.top,
                left: star.left,
                width: `${star.size}px`,
                height: `${star.size}px`,
                animationDuration: star.duration,
                animationDelay: star.delay,
              }}
            />
          ))}
        </div>
      </div>
      <div className="absolute top-1/4 -left-24 w-48 h-48 bg-gradient-to-br from-blue-400 to-purple-600 rounded-full opacity-30 animate-[planet-float1_10s_ease-in-out_infinite]"></div>
      <div className="absolute bottom-1/4 -right-20 w-32 h-32 bg-gradient-to-tl from-yellow-400 via-red-500 to-pink-500 rounded-full opacity-40 animate-[planet-float2_12s_ease-in-out_infinite]"></div>
      <div className="absolute top-0 left-[-150vw] w-full h-full overflow-hidden">
        <div className="absolute w-1 h-1 bg-white rounded-full shadow-[0_0_10px_5px_white] animate-[meteor_5s_linear_infinite] delay-1s"></div>
        <div className="absolute w-1 h-1 bg-white rounded-full shadow-[0_0_10px_5px_white] animate-[meteor_8s_linear_infinite] delay-3s"></div>
        <div className="absolute w-1 h-1 bg-white rounded-full shadow-[0_0_10px_5px_white] animate-[meteor_6s_linear_infinite] delay-5s"></div>
      </div>
    </>
  );
};

export default Background;
