import React, { useState, useEffect, useCallback } from 'react';

const LightsaberSVG = ({ color }: { color: string }) => (
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 40 180" style={{ transform: 'translate(-5px, -5px) rotate(-45deg)' }}>
        <defs>
            <filter id="glow">
                <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
                <feMerge>
                    <feMergeNode in="coloredBlur" />
                    <feMergeNode in="SourceGraphic" />
                </feMerge>
            </filter>
        </defs>
        {/* Blade */}
        <rect x="17" y="0" width="6" height="140" rx="3" fill="#FFF" />
        <rect x="17" y="0" width="6" height="140" rx="3" fill={color} style={{ filter: 'url(#glow)'}} />
        {/* Hilt */}
        <path d="M 15 140 L 15 150 L 25 150 L 25 140 Z" fill="#666" />
        <rect x="12" y="150" width="16" height="25" fill="#444" rx="2" />
        <rect x="16" y="145" width="8" height="3" fill="#000" />
    </svg>
);


const SaberCursor = () => {
    const [position, setPosition] = useState({ x: -100, y: -100 });
    const [saberColor, setSaberColor] = useState('#00DFFF'); // Jedi Blue
    const [clicks, setClicks] = useState<number[]>([]);
    const [showSithNotification, setShowSithNotification] = useState(false);

    useEffect(() => {
        document.body.style.cursor = 'none';
        return () => {
            document.body.style.cursor = 'default';
        };
    }, []);
    
    const handleMouseMove = useCallback((e: MouseEvent) => {
        setPosition({ x: e.clientX, y: e.clientY });
    }, []);

    const handleClick = useCallback(() => {
        const now = Date.now();
        // Keep clicks from the last 1.5 seconds
        const recentClicks = [...clicks, now].filter(time => now - time < 1500);

        if (recentClicks.length >= 5) {
            setSaberColor(prevColor => {
                const newColor = prevColor === '#00DFFF' ? '#FF0000' : '#00DFFF';
                if (newColor === '#FF0000') {
                    setShowSithNotification(true);
                }
                return newColor;
            });
            setClicks([]); // Reset after triggering
        } else {
            setClicks(recentClicks);
        }
    }, [clicks]);

    useEffect(() => {
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('click', handleClick);

        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('click', handleClick);
        };
    }, [handleMouseMove, handleClick]);

    useEffect(() => {
        if (showSithNotification) {
            const timer = setTimeout(() => {
                setShowSithNotification(false);
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [showSithNotification]);

    return (
        <>
            <style>{`
                @keyframes sith-fade {
                    0% { opacity: 1; transform: translateY(0); }
                    80% { opacity: 1; transform: translateY(0); }
                    100% { opacity: 0; transform: translateY(-20px); }
                }
                .animate-sith-fade {
                    animation: sith-fade 3s forwards;
                }
                body, button, a {
                    cursor: none !important;
                }
            `}</style>
            <div
                style={{
                    position: 'fixed',
                    top: position.y,
                    left: position.x,
                    zIndex: 9999,
                    pointerEvents: 'none',
                    transition: 'transform 0.1s ease-out',
                }}
            >
                <LightsaberSVG color={saberColor} />
            </div>
            {showSithNotification && (
                 <div className="fixed top-5 right-5 bg-red-900/80 border border-red-500 text-white p-3 rounded-lg z-[10000] animate-sith-fade">
                    Sith mode activated 🔴
                </div>
            )}
        </>
    );
};

export default SaberCursor;
