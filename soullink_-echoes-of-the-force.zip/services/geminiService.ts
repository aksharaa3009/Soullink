import { GoogleGenAI } from "@google/genai";
import { ResultData } from '../types';
import { QUESTIONS } from '../constants';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export async function findGalacticTwin(
  name: string,
  genre: string,
  answers: number[]
): Promise<ResultData> {
  const systemInstruction = `You are the SoulLink Oracle, an AI that connects individuals to their fictional soulmates.
Based on the user's name, their chosen universe (genre), and their answers to personality questions, you will identify their 'Galactic Twin'.

The user's name is '${name}'.
The chosen universe is '${genre}'.
The user answered the following questions:
${answers.map((answerIndex, questionIndex) => {
  const question = QUESTIONS[questionIndex];
  return `- ${question.question}: ${question.options[answerIndex]}`;
}).join('\n')}

Based on this, invent a compelling 'Galactic Twin' for the user. It can be an existing character from the chosen universe or a new, original character that fits the universe's theme. The personality of the twin should reflect the user's answers.

You MUST respond ONLY with a single, valid JSON object that follows this exact structure:
{
  "characterName": "string",
  "description": "A compelling, one-paragraph explanation of why this character is the user's twin, connecting their personality (based on the answers) to the character's traits within the chosen universe.",
  "strengths": "A comma-separated list of shared strengths.",
  "weaknesses": "A comma-separated list of shared weaknesses.",
  "voiceMessage": "A short, one or two-sentence message written in the first person from the character's perspective, as if speaking directly to the user."
}

Do not include any introductory text, closing remarks, code fences like \`\`\`json, or any other content outside of the JSON object.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: `Generate a Galactic Twin profile for a user named "${name}" who chose the genre "${genre}" and gave the answers provided in the system instructions.`,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.8,
      },
    });

    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    const parsedData = JSON.parse(jsonStr) as ResultData;

    if (!parsedData.characterName || !parsedData.description || !parsedData.strengths || !parsedData.weaknesses || !parsedData.voiceMessage) {
        throw new Error("Received incomplete data structure from API.");
    }

    return parsedData;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to communicate with the SoulLink Oracle. The cosmic streams are blurred.");
  }
}