import React, { useState, useCallback, useEffect } from 'react';
import { Screen, ResultData, Genre } from './types';
import IntroScreen from './components/IntroScreen';
import NameScreen from './components/NameScreen';
import GenreScreen from './components/GenreScreen';
import QuestionScreen from './components/QuestionScreen';
import LoadingScreen from './components/LoadingScreen';
import ResultScreen from './components/ResultScreen';
import Background from './components/Background';
import { findGalacticTwin } from './services/geminiService';
import { QUESTIONS } from './constants';
import SaberCursor from './components/SaberCursor';
import AlertModal from './components/AlertModal';
import { order66Sound, palpatineGif } from './components/assets';

export default function App() {
  const [screen, setScreen] = useState<Screen>(Screen.INTRO);
  const [username, setUsername] = useState<string>('');
  const [selectedGenre, setSelectedGenre] = useState<Genre | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [result, setResult] = useState<ResultData | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Easter Egg State
  const [keySequence, setKeySequence] = useState('');
  const [showOrder66Alert, setShowOrder66Alert] = useState(false);

  const handleStartJourney = () => setScreen(Screen.NAME);

  const handleNameSubmit = (name: string) => {
    setUsername(name);
    setScreen(Screen.GENRE);
  };

  const handleGenreSelect = (genre: Genre) => {
    setSelectedGenre(genre);
    setScreen(Screen.QUESTIONS);
  };
  
  const handleAnswer = (answerIndex: number) => {
    const newAnswers = [...answers, answerIndex];
    setAnswers(newAnswers);

    if (currentQuestionIndex < QUESTIONS.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setScreen(Screen.LOADING);
    }
  };

  const getTwin = useCallback(async () => {
    if (!username || !selectedGenre || answers.length !== QUESTIONS.length) return;

    try {
      setError(null);
      const twin = await findGalacticTwin(username, selectedGenre.name, answers);
      setResult(twin);
      setScreen(Screen.RESULT);
    } catch (e) {
      const errorMsg = e instanceof Error ? e.message : "An unknown error occurred.";
      console.error("Failed to get galactic twin:", errorMsg);
      setError("The cosmic connection failed. The Force may be imbalanced. Please try again.");
      setScreen(Screen.GENRE); // Go back to genre select on error
    }
  }, [username, selectedGenre, answers]);


  useEffect(() => {
    if(screen === Screen.LOADING) {
       getTwin();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen, getTwin]);

  // Order 66 Easter Egg listener
  useEffect(() => {
    const targetSequence = 'order66';
    const handler = (e: KeyboardEvent) => {
      // Ignore inputs in form fields
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
        
      const newSequence = (keySequence + e.key).slice(-targetSequence.length);
      setKeySequence(newSequence);

      if (newSequence.toLowerCase() === targetSequence) {
        const audio = new Audio(order66Sound);
        audio.play();
        setShowOrder66Alert(true);
        setKeySequence(''); // Reset to prevent re-triggering
      }
    };
    
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [keySequence]);


  const handleRestart = () => {
    setScreen(Screen.INTRO);
    setUsername('');
    setSelectedGenre(null);
    setAnswers([]);
    setCurrentQuestionIndex(0);
    setResult(null);
    setError(null);
  };

  const renderScreen = () => {
    switch (screen) {
      case Screen.INTRO:
        return <IntroScreen onStart={handleStartJourney} />;
      case Screen.NAME:
        return <NameScreen onSubmit={handleNameSubmit} />;
      case Screen.GENRE:
        return <GenreScreen onSelect={handleGenreSelect} error={error} />;
      case Screen.QUESTIONS:
        return <QuestionScreen 
                  question={QUESTIONS[currentQuestionIndex]} 
                  onAnswer={handleAnswer} 
                  questionNumber={currentQuestionIndex + 1}
                  totalQuestions={QUESTIONS.length}
               />;
      case Screen.LOADING:
        return <LoadingScreen />;
      case Screen.RESULT:
        return result && <ResultScreen result={result} onRestart={handleRestart} />;
      default:
        return <IntroScreen onStart={handleStartJourney} />;
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden">
      <SaberCursor />
      <Background />
      <main className="relative z-10 flex items-center justify-center h-full p-4">
        {renderScreen()}
      </main>
      {showOrder66Alert && (
         <AlertModal onClose={() => setShowOrder66Alert(false)}>
            <div className="flex flex-col items-center">
                <img src={palpatineGif} alt="Emperor Palpatine" className="rounded-lg mb-4 w-64 h-auto" />
                <h2 className="text-2xl font-orbitron text-red-400">The time has come.</h2>
                <p className="text-lg text-white mt-2">Execute Order 66.</p>
            </div>
         </AlertModal>
      )}
    </div>
  );
}