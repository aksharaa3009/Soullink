import { Genre, Question } from './types';

export const GENRES: Genre[] = [
  { id: 'starwars', name: 'Star Wars', imageUrl: 'https://images-cdn.ubuy.co.in/678a37833376e342c67f9455-trends-international-star-wars.jpg' },
  { id: 'marvel', name: 'Marvel', imageUrl: 'https://images-cdn.ubuy.co.in/6498157efb5aa9286756b001-marvel-comics-poster-multi-colour-61-x.jpg' },
  { id: 'anime', name: 'Anime', imageUrl: 'https://assets.aboutamazon.com/dims4/default/618814b/2147483647/strip/true/crop/1279x720+0+0/resize/1240x698!/quality/90/?url=https%3A%2F%2Famazon-blogs-brightspot.s3.amazonaws.com%2F4d%2F45%2Fd46f0da841cd85b66504278d4003%2Fcrunchyrollpv.jpg' },
  { id: 'kdrama', name: 'K-Drama', imageUrl: 'https://preview.redd.it/netflix-squid-game-2-main-poster-premieres-december-26-v0-b9bl9ay2yb3e1.jpeg?auto=webp&s=113edb5b17dd98b6d1ee0e82dc4797d62c72d084' },
  { id: 'bollywood', name: 'Bollywood', imageUrl: 'https://m.media-amazon.com/images/M/MV5BNjM4MzFhOTItMzNmYy00NTg4LWFjYzItMWY0ZDAxY2NmNTUyXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg' },
  { id: 'harrypotter', name: 'Harry Potter', imageUrl: 'https://m.media-amazon.com/images/I/718OJKgQOcL._UF1000,1000_QL80_.jpg' },
];

export const QUESTIONS: Question[] = [
  {
    question: "When facing a great challenge, you rely on...",
    options: ["Strategy and logic", "Intuition and heart", "Friends and allies", "Sheer power and determination"]
  },
  {
    question: "Your ideal weapon is...",
    options: ["An energy blast from your hands", "Your own sharp mind", "A powerful ancient artifact", "A loyal companion who fights beside you"]
  },
  {
    question: "In a moment of crisis, your first instinct is to...",
    options: ["Protect the innocent", "Analyze the situation for a weakness", "Charge headfirst into battle", "Find a diplomatic solution"]
  },
  {
    question: "What drives you most?",
    options: ["Justice and peace", "Knowledge and discovery", "Power and ambition", "Love and loyalty"]
  }
];